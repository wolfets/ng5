import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-angular',
  templateUrl: './home-angular.component.html',
  styleUrls: ['./home-angular.component.scss']
})
export class HomeAngularComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
